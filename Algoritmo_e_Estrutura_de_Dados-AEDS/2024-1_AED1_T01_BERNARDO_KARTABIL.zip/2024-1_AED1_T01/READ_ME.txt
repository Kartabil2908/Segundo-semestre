Professor, eu não coloquei nada nas referências, pois não consegui entender como funciona a escrita das refêrencias no overleaf. Porém, como eu acho indispensável esse elemento, vou colocá-lo aqui:

VOLPATO, Gilson. AULA 20 de 42 - TRÊS TIPOS LÓGICOS DE PESQUISA. YouTube, 15 de mar. de 2012. Disponível em: "https://youtu.be/XoTQo7fUf0s?si=yU8XvKt19VymyhIP".