#ifndef _PROCEDIMENTOS_HPP_
#define _PROCEDIMENTOS_HPP_

void construir_menu()
{
    std::cout << "1 - Construir a planilha com valor nulo" << std::endl;
    std::cout << "2 - Atualizar TODA a planilha" << std::endl;

}
/*planilha metodo_01()
{
    int alun1;
    int materias;
    std::cout << "Digite o número de matérias que os alunos estão cursando: ";
    std::cin >> materias;
    std::getchar();

    std::cout << std::endl << "Se quiser, já pode definir o número de alunos da planilha, se não quiser, digite 0" << std::endl;            
    std::cin >> alun1;
    std::getchar();
    planilha plan1(alun1,materias);

    return (plan1);
}*/




#endif