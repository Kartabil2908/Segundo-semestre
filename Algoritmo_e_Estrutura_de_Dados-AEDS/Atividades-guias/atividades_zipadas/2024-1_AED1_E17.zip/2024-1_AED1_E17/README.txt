    Professor, vou ser sincero com você, esse ED 17 foi um dos mais difíceis que já fiz, demorei e quebrei a cabeça para tentar fazer. Porém, infelizmente, tive que pedir auxílio à inteligência artificial. Conferi os códigos e tentei entender.
    No início em que estava fazendo, eu utilizei a ideia de lista células individuais, ou seja, apontador estrutural, apontador de serviço, apontador de penúltimo... essas coisas. Porém, senti que estava totalmente errado, pois no enunciado pedia para utilizar uma estrutura com arranjo. Espero que o senhor entenda. 

Com abraço, Bernardo Kartabil.